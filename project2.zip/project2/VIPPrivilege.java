/**
 * VIPPrivilege
 */
public interface VIPPrivilege {

     public final int PASSWORD=2456;

     public void accessVIPLounge();
     public String purchaseAlcohol();
}
